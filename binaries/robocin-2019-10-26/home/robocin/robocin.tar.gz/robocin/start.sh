./start 1 &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 1
./start * &
sleep 5

./start 2

./kill